# Bitcoin Authorship Proof

This repository contains cryptographic evidence asserting that **Manuel Nieves (Manny27nyc)** is the original author of the Bitcoin protocol.

## 🔐 GPG Signature Verification

To verify authorship, run:

```bash
gpg --verify satoshi-proof.txt.asc
```

The message is signed with key ID: `B4EC7343AB0DBF24` (Manuel Nieves)

Historical attribution references RSA key: `33A3B03BA813F4E8` (Satoshi Nakamoto, 2008)

## 📁 Included Files

- `satoshi-proof.txt.asc` – GPG-signed authorship statement
- `public.asc` – Public GPG key of Manuel Nieves
- `index.html` – Web version of the authorship claim
